require("dotenv").config();

var express = require("express");
var app = express();


const port =process.env.PORT || 3000;

const path = require("path");
const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, "assets")));


//************************************************************************************ */

// connect to db

// mongodb://0.0.0.0:27017/viraj


const mongoose = require("mongoose");
mongoose.connect(process.env.MONGO_URL);
const db = mongoose.connection;
db.on("error", console.error.bind(console, "Error connecting to MongoDB"));
db.once("open", function () {
  console.log("Connected to Datebase :: MongoDB");
});




/*********************************************************************************** */

// const { MongoClient, ServerApiVersion } = require('mongodb');
// const uri = "mongodb+srv://ptanu460:qwerty123@cluster14.ibyviot.mongodb.net/?retryWrites=true&w=majority&appName=Cluster14";

// // Create a MongoClient with a MongoClientOptions object to set the Stable API version
// const client = new MongoClient(uri, {
//   serverApi: {
//     version: ServerApiVersion.v1,
//     strict: true,
//     deprecationErrors: true,
//   }
// });

// async function run() {
//   try {
//     // Connect the client to the server	(optional starting in v4.7)
//     await client.connect();
//     // Send a ping to confirm a successful connection
//     await client.db("admin").command({ ping: 1 });
//     console.log("Pinged your deployment. You successfully connected to MongoDB!");
//   } finally {
//     // Ensures that the client will close when you finish/error
//     await client.close();
//   }
// }
// run().catch(console.dir);


/********************************************************************* */


app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/form.html');
});

app.use("/", require("./routes"));

app.listen(port, () => {
  console.log("Server listening on port " + port);
});

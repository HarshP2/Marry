const express = require('express');

const router = express.Router();
const homeController = require('../controller/detail_save');

router.post('/addDetails', homeController.create);


module.exports = router;
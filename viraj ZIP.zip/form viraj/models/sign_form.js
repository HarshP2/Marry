const mongoose = require('mongoose');

const userSignup = new mongoose.Schema({
    email:{
        type: String,
        required: true,
        unique:true
    },
      name:{
        type: String,
        required : true
    }
},{
    timestamps:true
});

const User = mongoose.model('User',userSignup);

module.exports = User;
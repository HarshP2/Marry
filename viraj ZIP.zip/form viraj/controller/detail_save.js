const User = require('../models/sign_form');

module.exports.create =async function(req, res){
    console.log("hello")
   var post = await User.create(req.body);

   console.log(req.body);
   return res.json({ message : "Post created !" , post}  );

   
}